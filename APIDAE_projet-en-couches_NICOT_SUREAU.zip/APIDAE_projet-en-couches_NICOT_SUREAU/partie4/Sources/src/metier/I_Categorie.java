package metier;

public interface I_Categorie {

	public String getNom();
	public float getTauxTVA();
}
