package dal;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.jdom.*;
import org.jdom.input.*;
import org.jdom.output.*;
import org.w3c.dom.NodeList;
import metier.I_Produit;
import metier.Produit;


public class ProduitDAO_XML {
	private String uri = "Produits.xml";
	private Document doc;

	public ProduitDAO_XML() {
		SAXBuilder sdoc = new SAXBuilder();
		try {
			doc = sdoc.build(uri);
		} catch (Exception e) {
			System.out.println("erreur construction arbre JDOM");
		}
	}

	public boolean creer(I_Produit p) {
		try {
			Element root = doc.getRootElement();
			Element prod = new Element("produit");
			prod.setAttribute("nom", p.getNom());
			Element prix = new Element("prixHT");
			prod.addContent(prix.setText(String.valueOf(p.getPrixUnitaireHT())));
			Element qte = new Element("quantite");
			prod.addContent(qte.setText(String.valueOf(p.getQuantite())));
			Element nomcat = new Element("nomcatalogue");
			prod.addContent(nomcat.setText(String.valueOf(p.getNomCatalogue())));
			root.addContent(prod);
			return sauvegarde();
		} catch (Exception e) {
			System.out.println("erreur creer produit");
			return false;
		}
	}

	public boolean maj(I_Produit p) {
		try {
			Element prod = chercheProduit(p.getNom());
			if (prod != null) {
				prod.getChild("quantite").setText(String.valueOf(p.getQuantite()));
				return sauvegarde();
			}
			return false;
		} catch (Exception e) {
			System.out.println("erreur maj produit");
			return false;
		}
	}

	public boolean supprimer(I_Produit p) {
		try {
			Element root = doc.getRootElement();
			Element prod = chercheProduit(p.getNom());
			if (prod != null) {
				root.removeContent(prod);
				return sauvegarde();
			} else
				return false;
		} catch (Exception e) {
			System.out.println("erreur supprimer produit");
			return false;
		}
	}

	public I_Produit lire(String nom) {
		Element e = chercheProduit(nom);
		if (e != null)
			return new Produit(e.getAttributeValue("nom"), Double.parseDouble(e.getChildText("prixHT")), Integer.parseInt(e.getChildText("quantite")), e.getAttributeValue("nomcatalogue"));
		else
			return null;
	}

	public List<I_Produit> lireTous(String nomCatalogue) {

		List<I_Produit> l = new ArrayList<I_Produit>();
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		    factory.setNamespaceAware(true); 
		    DocumentBuilder builder = factory.newDocumentBuilder();
		    org.w3c.dom.Document docP = builder.parse("Produits.xml");
			XPathFactory xpf = XPathFactory.newInstance();
	        XPath xpath = xpf.newXPath();
	        XPathExpression expr = xpath.compile("//produit[nomcatalogue='"+nomCatalogue+"']");
	        Object result = expr.evaluate(docP, XPathConstants.NODESET);
	        NodeList nodes = (NodeList) result;
	        for(int i = 0 ; i < nodes.getLength() ; i++){
				String nomP = nodes.item(i).getAttributes().item(0).getTextContent();
				Double prix = Double.valueOf(nodes.item(i).getChildNodes().item(0).getTextContent());
				int qte = Integer.valueOf(nodes.item(i).getChildNodes().item(1).getTextContent());
				l.add(new Produit(nomP, prix, qte, nomCatalogue));
			}
		} catch (Exception e) {
			System.out.println("erreur lireTous tous les produits");
			System.out.println(e.getMessage());
		}
		return l;
	}

	private boolean sauvegarde() {
		System.out.println("Sauvegarde");
		XMLOutputter out = new XMLOutputter();
		try {
			out.output(doc, new PrintWriter(uri));
			return true;
		} catch (Exception e) {
			System.out.println("erreur sauvegarde dans fichier XML");
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	private Element chercheProduit(String nom) {
		Element root = doc.getRootElement();
		List<Element> lProd = root.getChildren("produit");
		int i = 0;
		while (i < lProd.size() && !lProd.get(i).getAttributeValue("nom").equals(nom))
			i++;
		if (i < lProd.size())
			return lProd.get(i);
		else
			return null;
	}
	
}
